<?php
if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToInsertRecords(
    'tx_kkdownloader_images'
);

$GLOBALS['TCA']['tx_kkdownloader_images']['columns']['longdescription']['config']['richtextConfiguration'] = 'qpx';
